export CUDA_VISIBLE_DEVICES='2,3,4,5,6'

python gan_train.py -c ./configs/config_gan_train.yaml
