export CUDA_VISIBLE_DEVICES='2,3'

python train.py -c ./configs/config_generator_train.yaml
