export CUDA_VISIBLE_DEVICES='0,1,2,3,4,5,6,7'

python generate_samples.py -c ./configs/config_generate_sample.yaml
